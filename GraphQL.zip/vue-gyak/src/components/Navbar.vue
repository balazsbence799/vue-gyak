<template>
  <nav class="navbar">
    <button
      :class="['nav-btn', { active: current === 'rest' }]"
      @click="$emit('switch', 'rest')"
    >
      REST API
    </button>

    <button
      :class="['nav-btn', { active: current === 'graphql' }]"
      @click="$emit('switch', 'graphql')"
    >
      GraphQL API
    </button>
  </nav>
</template>

<script>
export default {
  props: {
    current: {
      type: String,
      required: true
    }
  }
}
</script>

<style scoped>
.navbar {
  display: flex;
  justify-content: center;
  gap: 12px;
  margin-bottom: 32px;
}

.nav-btn {
  border-radius: 999px;
  padding: 10px 22px;
  border: none;
  background: #f2f2f2;
  cursor: pointer;
  font-size: 1rem;
}

.nav-btn.active {
  background: #222;
  color: #fff;
}
</style>
