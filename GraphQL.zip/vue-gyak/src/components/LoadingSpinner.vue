<template>
  <div class="spinner-wrapper">
    <div class="spinner"></div>
  </div>
</template>

<style scoped>
.spinner-wrapper {
  display: flex;
  justify-content: center;
  margin: 16px 0;
}

.spinner {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 4px solid #e0e0e0;
  border-top-color: #1976d2;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
