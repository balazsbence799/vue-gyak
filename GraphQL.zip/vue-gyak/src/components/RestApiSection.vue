<template>
  <div class="panel">
    <h2>REST API</h2>

    <button class="load-btn" @click="fetchUsers" :disabled="loading">
      {{ loading ? 'Betöltés...' : 'Load Users (REST API)' }}
    </button>

    <LoadingSpinner v-if="loading" />
    <ProgressBar
      v-if="progress > 0 && progress < 100"
      :progress="progress"
    />

    <div v-if="error" class="error">{{ error }}</div>

    <ul>
      <li v-for="user in users" :key="user.id" class="user-card">
        <strong>{{ user.name }}</strong><br />
        <span><span class="icon">📧</span>{{ user.email }}</span><br />
        <span><span class="icon">📞</span>{{ user.phone }}</span>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'
import LoadingSpinner from './LoadingSpinner.vue'
import ProgressBar from './ProgressBar.vue'

export default {
  components: { LoadingSpinner, ProgressBar },
  data() {
    return {
      users: [],
      loading: false,
      error: null,
      progress: 0
    }
  },
  methods: {
    async fetchUsers() {
      this.loading = true
      this.error = null
      this.users = []
      this.progress = 10

      try {
        // csak demó kedvéért “lassítjuk”
        setTimeout(() => {
          this.progress = 60
        }, 500)

        const response = await axios.get(
          'https://jsonplaceholder.typicode.com/users'
        )

        this.users = response.data.slice(0, 10)
        this.progress = 100
      } catch (err) {
        this.error = 'Hiba: ' + err.message
      } finally {
        this.loading = false
        // kis idő múlva eltüntetjük a csíkot
        setTimeout(() => {
          this.progress = 0
        }, 400)
      }
    }
  }
}
</script>

<style scoped>
.panel {
  margin: 0 auto;
  padding: 24px;
  border-radius: 16px;
  background: #ffffff;
  max-width: 540px;
  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
}

h2 {
  margin-bottom: 16px;
}

.load-btn {
  background: #1976d2;
  color: white;
  border: none;
  padding: 10px 22px;
  border-radius: 6px;
  cursor: pointer;
  margin-bottom: 12px;
}

.load-btn:disabled {
  opacity: 0.7;
  cursor: default;
}

.user-card {
  list-style: disc;
  margin-left: 18px;
  margin-bottom: 10px;
  text-align: left;
}

.icon {
  color: #e10098;
  margin-right: 4px;
}

.error {
  color: red;
  margin-top: 8px;
  margin-bottom: 8px;
}
</style>
