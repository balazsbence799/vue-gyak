<template>
  <div class="progress-bar">
    <div class="progress" :style="{ width: progress + '%' }"></div>
  </div>
</template>

<script>
export default {
  props: {
    progress: {
      type: Number,
      required: true
    }
  }
}
</script>

<style scoped>
.progress-bar {
  width: 100%;
  background: #eee;
  height: 8px;
  border-radius: 999px;
  overflow: hidden;
  margin: 12px 0 24px;
}

.progress {
  height: 100%;
  background: #1976d2;
  transition: width 0.3s ease;
}
</style>
