<template>
  <div class="panel">
    <h2>GraphQL API</h2>

    <button class="load-btn" @click="fetchUsersGraphQL" :disabled="loading">
      {{ loading ? 'Betöltés...' : 'Load Users (GraphQL)' }}
    </button>

    <LoadingSpinner v-if="loading" />
    <ProgressBar
      v-if="progress > 0 && progress < 100"
      :progress="progress"
    />

    <div v-if="error" class="error">{{ error }}</div>

    <ul>
      <li v-for="user in users" :key="user.id" class="user-card">
        <strong>{{ user.name }}</strong><br />
        <span><span class="icon">📧</span>{{ user.email }}</span><br />
        <span><span class="icon">📞</span>{{ user.phone }}</span>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'
import LoadingSpinner from './LoadingSpinner.vue'
import ProgressBar from './ProgressBar.vue'

export default {
  components: { LoadingSpinner, ProgressBar },
  data() {
    return {
      users: [],
      loading: false,
      error: null,
      progress: 0
    }
  },
  methods: {
    async fetchUsersGraphQL() {
      this.loading = true
      this.error = null
      this.users = []
      this.progress = 20

      const query = `
        {
          users {
            data {
              id
              name
              email
              phone
            }
          }
        }
      `

      try {
        setTimeout(() => {
          this.progress = 70
        }, 500)

        const resp = await axios.post(
          'https://graphqlzero.almansi.me/api',
          { query },
          { headers: { 'Content-Type': 'application/json' } }
        )

        if (resp.data.errors && resp.data.errors.length) {
          throw new Error(resp.data.errors[0].message)
        }

        this.users = resp.data.data.users.data
        this.progress = 100
      } catch (e) {
        this.error = 'Hiba: ' + e.message
      } finally {
        this.loading = false
        setTimeout(() => {
          this.progress = 0
        }, 400)
      }
    }
  }
}
</script>

<style scoped>
.panel {
  margin: 0 auto;
  padding: 24px;
  border-radius: 16px;
  background: #ffffff;
  max-width: 540px;
  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
}

h2 {
  margin-bottom: 16px;
}

.load-btn {
  background: #1976d2;
  color: white;
  border: none;
  padding: 10px 22px;
  border-radius: 6px;
  cursor: pointer;
  margin-bottom: 12px;
}

.load-btn:disabled {
  opacity: 0.7;
  cursor: default;
}

.user-card {
  list-style: disc;
  margin-left: 18px;
  margin-bottom: 10px;
  text-align: left;
}

.icon {
  color: #e10098;
  margin-right: 4px;
}

.error {
  color: red;
  margin-top: 8px;
  margin-bottom: 8px;
}
</style>
